plot_pdf <- function( part_tmp,i,n){
  pdata <- rep(0, 100);

  for(j in 1:n){
      val=round(part_tmp[j], 0);
      if(val <= n)pdata[val] = pdata[val] + 1/n;
  }

  xcols <- c(0:99)
  plot(xcols, pdata, "l", xlab="X", ylab=paste("pdf",i,"(x)", sep = " "))
}
plot_cdf <- function( part_tmp,i,n){
  pdata <- rep(0, 100);
  for(j in 1:n){
      val=round(part_tmp[j], 0);
      if(val <= n)pdata[val] = pdata[val] + 1/n;
  }
  for(j in 2:100)pdata[j]=pdata[j]+pdata[j-1];


  xcols <- c(0:99)
  plot(xcols, pdata, "l", xlab="X", ylab=paste("cdf",i,"(x)", sep = " "))
}

plot_pdf2 <- function(part_tmp,i,n,s,mu){
  pdata <- rep(0,5*s);

  for(j in 1:n){
      val=round(s*part_tmp[j], 0);
      val=val-mu*s+5*s/2;
      if(val <= 5*s)pdata[val] = pdata[val] + 1/500;
  }

  xcols <- c(0:(5*s-1))
  xcols <- xcols/s-5/2.0+mu;
  plot(xcols, pdata, "l", xlab="X", ylab=paste("pdf",i,"(x)", sep = " "))
}
plot_cdf2 <- function(part_tmp,i,n,s,mu){
  pdata <- rep(0,5*s);

  for(j in 1:n){
      val=round(s*part_tmp[j], 0);
      val=val-mu*s+5*s/2;
      if(val <= 5*s)pdata[val] = pdata[val] + 1/500;
  }
  for(j in 2:(5*s))pdata[j]=pdata[j]+pdata[j-1];

  xcols <- c(0:(5*s-1))
  xcols <- xcols/s-5/2.0+mu;
  plot(xcols, pdata, "l", xlab="X", ylab=paste("cdf",i,"(x)", sep = " "))
}

mu_sd <- function( part_tmp,i,n){
  mu=0;sd=0;
  for(j in 1:n){
      mu=mu+part_tmp[j];
      sd=sd+part_tmp[j]^2;
  }
  mu=mu/n;sd=sd/n;
  sd=sd-mu^2;
  sd=sd^0.5;

  print(paste("#sample ",i,": Mean=",mu,", Standard Deviation=",sd, sep = ""))
}
mu_sd2 <- function( part_tmp,i,n){
  mu=0;sd=0;
  for(j in 1:n){
      mu=mu+part_tmp[j];
      sd=sd+part_tmp[j]^2;
  }
  mu=mu/n;sd=sd/n;
  sd=sd-mu^2;
  sd=sd^0.5;

  return(mu);
}


num_samples <- 50000
lamda <- 0.2
m<-500

l <- lamda
data <- rexp(num_samples, l)

x <- data.frame(X = seq(1, num_samples , 1), Y = sort(data))# Scatter Plot
plot(x)

n<-round(num_samples/m)
part<- three_d_array <- array(1:num_samples,dim=c(m,n))

for(i in 1:m)part[i,1:n]<-data[(i*n-n+1):(n*i)]#partitioning data

for(i in 1:5)plot_pdf(part[i,1:n],i,n);#pdf
for(i in 1:5)plot_cdf(part[i,1:n],i,n);#cdf
for(i in 1:5)mu_sd(part[i,1:n],i,n);#mean and sd

norm<-rep(0,5);
for(i in 1:m)norm[i]=mu_sd2(part[i,1:n],i,n);#calculation means of partitions

tab <- table(round(norm))
plot(tab, "h", xlab="Value", ylab="Frequency")
plot_pdf2(norm,"of all distribution",m,2,1/l);#pdf
plot_cdf2(norm,"of all distribution",m,2,1/l);#cdf
mu_sd(norm,"of all distribution",m);#mean and sd
