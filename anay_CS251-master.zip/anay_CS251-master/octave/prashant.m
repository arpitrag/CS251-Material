train = csvread("train.csv");
x=train(:,1);
y=train(:,2);
x = [ones(rows(y), 1) x];


w=rand(2,1);


figure;
scatter(x(:,2),y);
hold on;
#plot(x,y);
#newcol = ones(rows(y),1);
#x=[newcol x];
xdash= x*w;
plot(x(:,2),xdash);
#plot(x(:,2),y)

m=(x')*x;
n=inv(m);
o=(x')*y;
#scatter(x(:,2),y);
w_direct=(n*o);
#plot(x(:,2),y)
w_directa=(x*w_direct);
plot(x(:,2),w_directa);
#plot(x(:,1),y)


eta=1e-8;
p=length(y);
for i = (1:2)
  for j = (1:p)
    q=x(j,:)';
    r=(transpose(w))*q;
    s=(r-(y(j,:)));
    t=s*q;
    u=(eta)*t;
    w=(w-u);
    if mod(j,100)==0
      h=(x*w);
      plot(x(:,2),h);
	  pause(0.01);
    end
  end
end
h=(x*w);
plot(x(:,2),h);

test = csvread("test.csv");
x1=test(:,1);
y1=test(:,2);

x1=[ones(rows(y1), 1),x1];

#x1=np.insert(x1,0,1,axis=1);

y_pred1=(x1*w);
a1=(y_pred1-y1);
a2=(a1'*a1);
r1=a2/rows(y1);
r2=sqrt(r1);

#printf('y_pred1 error:');
#printf(r2);

y_pred2=(x1*w_direct);
b1=(y_pred2-y1);
b3=transpose(b1);
b2=(b3*b1);
rt1=b2/rows(y1);
rt2=sqrt(rt1);

#pause(20);
print -dpdf "a.pdf";
close;
#printf('y_pred2 error:');
#printf(rt2);
