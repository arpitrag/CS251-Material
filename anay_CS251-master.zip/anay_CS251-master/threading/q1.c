#include<stdio.h>
#include<stdlib.h>
#include<sys/time.h>
#include<string.h>
#include<pthread.h>
#include<math.h>

typedef long long int ll;
#define rep(i,n) for(ll i=0;i<(n);++i)
#define repA(i,a,n) for(ll i=(a);i<=(n);++i)
#define repD(i,a,n) for(ll i=(a);i>=(n);--i)


#define SEED 0x7457
#define MAX_THREADS 64
#define USAGE_EXIT(s) do{ \
                             printf("Usage: %s <# of elements> <# of numt> \n %s\n", argv[0], s); \
                            exit(-1);\
                    }while(0);

#define TDIFF(start, end) ((end.tv_sec - start.tv_sec) * 1000000UL + (end.tv_usec - start.tv_usec))

struct thread_param{
  pthread_t tid;
  int *array;
  int size;
  int thread_ctr;
  int skip;
  double max;
  int max_index;
};

const ll MAX=RAND_MAX/50;
int prime[MAX];

void pre(){
  rep(i,MAX)prime[i]=1;

  prime[1]=0;
  for(ll i=2;i*i<=MAX;i++)if(prime[i]==1)for(ll j=2*i;j<MAX;j+=i)prime[j]=0;
  printf("Finished preprocessing\n");
}

void* find_max_prime(void *arg)
{
     struct thread_param *trd=(struct thread_param *) arg;
     int ctr=trd->thread_ctr;

     trd->max=-1;
     trd->max_index=-1;

     ctr += trd->skip;
     while(ctr < trd->size){
           int x=trd->array[ctr];
           if(x*prime[x]>trd->max){
                trd->max=x;
                trd->max_index=ctr;
           }
           ctr+=trd->skip;
     }
     return NULL;
}

int main(int argc, char **argv)
{
  struct thread_param *threads;
  struct timeval start, end;
  int *a, num, ctr, numt;
  int max=-1;
  int max_index;

  pre();
    if(argc!=3)USAGE_EXIT("not enough parameters");

    num=atoi(argv[1]);
    if(num <=0)USAGE_EXIT("invalid num elements");
    numt=atoi(argv[2]);
    if(numt <=0 || numt > MAX_THREADS){USAGE_EXIT("invalid num of numt");}
    /* Parameters seems to be alright. Lets start our business*/

    a=malloc(num * sizeof(int));
    if(!a){USAGE_EXIT("invalid num elements, not enough memory");}

    srand(SEED);
    for(ctr=0; ctr<num; ++ctr)a[ctr]=rand()%MAX;

  /*Allocate thread specific parameters*/
  threads=malloc(numt * sizeof(struct thread_param));
  bzero(threads, numt * sizeof(struct thread_param));
  gettimeofday(&start, NULL);

  /*Partion data and create threads*/
  for(ctr=0; ctr < numt; ++ctr){
        struct thread_param *tmp=threads + ctr;
        tmp->size=num;
        tmp->skip=numt;
        tmp->array=a;

        if(pthread_create(&tmp->tid, NULL, find_max_prime, tmp) != 0){
              perror("pthread_create");
              exit(-1);
        }

  }

  /*Wait for threads to finish their execution*/
  for(ctr=0; ctr < numt; ++ctr){
        struct thread_param *tmp=threads+ctr;
        pthread_join(tmp->tid, NULL);
        if(ctr == 0 || (ctr > 0 && tmp->max > max && tmp->max!=-1)){
             max=tmp->max;
             max_index=tmp->max_index;
        }
  }

  if(max<0)printf("No prime in array\n");
  else printf("Max=%d at index=%d\n", max, max_index);
  gettimeofday(&end, NULL);
  printf("Time taken=%ld microsecs\n", TDIFF(start, end));
  free(a);
  free(threads);
}
