#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<pthread.h>

#define rep(i,n) for(int i=0;i<(n);++i)
#define repA(i,a,n) for(int i=(a);i<=(n);++i)
#define repD(i,a,n) for(int i=(a);i>=(n);--i)
typedef long long int ll;
typedef unsigned long ul;

const int MAX_THREADS=64;
int nt=1;
#define BLOCK_SIZE 64

struct thread_param{
  pthread_t tid;
  int num=0;
  int pos=0;
};

pthread_mutex_t lock[10000],ilck,pos[MAX_THREADS],clck;
int pos[MAX_THREADS]={0},cur=0;
int ins=0,iid=-1;


struct account {
  int id;
  float m;
};
struct transaction {
  int ty;
  float m;
  int a,b;
};
struct transaction txn[10000];//variable
struct account acc[10000];


void calculate_and_execute(int i)
{
    hashval;
}

void* solve(void *t)
{
  int i;
  while(1){
      pthread_mutex_lock(&clck);

      pthread_mutex_lock(&pos[t->num]);
        t->pos=i=cur;
      pthread_mutex_unlock(&pos[t->num]);

      if(cur<nt){
        cur++;
        pthread_mutex_unlock(&clck);
      }
      else{
        pthread_mutex_unlock(&clck);
        break;
      }

      if(txn[i].id==3){
        pthread_mutex_lock(&ilck);
          ins=1,iid=t->num;
        pthread_mutex_unlock(&ilck);

        while(true){
            int ff=1;
            repA(j,0,THREADS)if(j!=t->num){
              pthread_mutex_lock(&pos[j]);
                if(th[j]->pos<)
            }

            if(ff==1)break;
            else{
              pthread_mutex_lock(&ilck);
                ins=0,iid=-1;
              pthread_mutex_unlock(&ilck);
            }
        }
      }
      else{



      }

      calculate_and_execute(t->pos);
  }

  pthread_exit(NULL);
}

void readAcc(char* file,int num){
  FILE* facc;
  facc = fopen(file, "r");
  if(facc==NULL){printf("Can not open account file\n");exit(-1);}

  int i=0,tt=0;
  fscanf(facc, "%d", &acc[i].id);
  fscanf(facc, "%f", &acc[i].m);
  i++;
  while (!feof(facc)&&i<num)
  {
    fscanf(facc, "%d", &acc[i].id);
    if(acc[i].id==0){printf("Not enough accounts in file\n");exit(-1);}
    fscanf(facc, "%f", &acc[i].m);
    i++;
  }
  if(i<num){printf("Not enough accounts in file\n");exit(-1);}

  fclose(facc);
}
void readTrans(char* file,int num){
  FILE * ftxn;
  ftxn = fopen(file, "r");
  if(ftxn==NULL){printf("Can not open transaction file\n");exit(-1);}

  int i=0,tt=0;
  fscanf (ftxn, "%d", &tt);//tmp value
  fscanf(ftxn, "%d", &txn[i].ty);
  fscanf(ftxn, "%f", &txn[i].m);
  fscanf(ftxn, "%d", &txn[i].a);
  fscanf(ftxn, "%d", &txn[i].b);
  i++;
  while (!feof(ftxn)&&i<num)
  {
    fscanf (ftxn, "%d", &tt);//tmp value
    if(tt==0){printf("Not enough transactions in file\n");exit(-1);}
    fscanf(ftxn, "%d", &txn[i].ty);
    fscanf(ftxn, "%f", &txn[i].m);
    fscanf(ftxn, "%d", &txn[i].a);
    fscanf(ftxn, "%d", &txn[i].b);
    i++;
  }
  if(i<num){printf("Not enough transactions in file\n");exit(-1);}
  fclose(ftxn);
}

int main(int argc, char **argv)
{
    pthread_t threads[THREADS];

    if(argc!=5){printf("Usage: %s <accounts> <transaction> #transaction #threads\n", argv[0]);exit(-1);}

    readAcc(argv[1],10000);
    readTrans(argv[2],atoi(argv[3]));

    nt=atoi(argv[4]);
    if(nt>MAX_THREADS){printf("Use less than %d threads.\n",MAX_THREADS);exit(-1);}

    struct thread_param th[MAX_THREADS];
    rep(i,THREADS)th[i].num=i;
    rep(i,THREADS){if(pthread_create(&th[i].tid, NULL, solve, &th[i])!=0){perror("pthread_create");exit(-1);}}
    rep(i,THREADS)pthread_join(th[i], NULL);

    rep(i,9990,10000)printf("%d,%.2f\n",acc[i].id,acc[i].m);

    return 0;
}
