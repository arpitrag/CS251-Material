#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<pthread.h>

#define fill(a) (memset((a), 0, sizeof (a)))
#define rep(i,n) for(int i=0;i<(n);++i)
#define repA(i,a,n) for(int i=(a);i<=(n);++i)
#define repD(i,a,n) for(int i=(a);i>=(n);--i)
typedef long long int ll;
typedef unsigned long ul;


int main(int argc, char **argv)
{
    if(argc!=2){printf("Usage: %s #transactions\n", argv[0]);exit(-1);}

    int MAX=atoi(argv[1]);
    FILE* out=fopen("txn_test.txt","w");

    rep(i,MAX){
      int ty=rand()%4+1,a=rand()%5000+1010,b=rand()%5000+1010;
      float m=(rand()%10000000)/100.0;
      if(ty==1)fprintf(out, "%d %d %.2f %d %d\n",i,ty,m,a,0);
      else if(ty==2)fprintf(out, "%d %d %.2f %d %d\n",i,ty,m,a,0);
      else if(ty==3)fprintf(out, "%d %d %.2f %d %d\n",i,ty,0.0,a,0);
      else if(ty==4)fprintf(out, "%d %d %.2f %d %d\n",i,ty,m,a,b);
    }
    fclose(out);

    return 0;
}
