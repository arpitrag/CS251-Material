#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<pthread.h>

#define rep(i,n) for(int i=0;i<(n);++i)
#define repA(i,a,n) for(int i=(a);i<=(n);++i)
#define repD(i,a,n) for(int i=(a);i>=(n);--i)
typedef long long int ll;
typedef unsigned long ul;


// #define THREADS 1
const int MAX_THREADS=64;
int THREADS=1;
#define BLOCK_SIZE 64

pthread_mutex_t lock;
static char *dataptr;
static ul *optr;//pointer to current hash


struct account {
  int id;
  float m;
}

struct transaction {
  int ty;
  float m;
  int a,b;
}

struct transaction * txn;
struct account * acc;


// ul calculate_and_store_hash(char *ptr, char *endptr)
// {
//    return hashval;
// }

// void *hashit(void *arg)
// /*Argument is the end pointer*/
// {
//    char *cptr;
//    ul *chash;
//    char *endptr = (char *)arg;
//
//    while(1){
//         pthread_mutex_lock(&lock);
//         if(dataptr >= endptr){
//               pthread_mutex_unlock(&lock);
//               break;
//         }
//         cptr = dataptr;
//         dataptr += BLOCK_SIZE;
//
//         chash = optr;
//         optr++;
//         pthread_mutex_unlock(&lock);
//
//         /*Perform the real calculation*/
//         *chash = calculate_and_store_hash(cptr, endptr);
//   }
//   pthread_exit(NULL);
// }

int main(int argc, char **argv)
{
    int facc; FILE* ftxn;
    ul asize, tsize, bytes_read = 0, hash_count;
    char *buff, *cbuff;
    ul *hashes;
    pthread_t threads[THREADS];

    if(argc != 5){printf("Usage: %s <accounts> <transaction> #transaction #threads\n", argv[0]);exit(-1);}

    facc = open(argv[1], O_RDONLY);
    if(facc < 0){printf("Can not open account file\n");exit(-1);}

    ftxn = fopen(argv[2], "r");
    if (ftxn == NULL){printf("Can not open transaction file\n");exit(-1);}

    txn = (transaction *)malloc(atoi(argv[3])*4*sizeof(transaction));
    if(!txn){perror("mem");exit(-1);}

    int i=0,c=sizeof(transaction);

    fscanf (ftxn, "%f", txn+i*c);//tmp value
    fscanf(ftxn, "%f", &((txn+i*c)->ty));
    fscanf(ftxn, "%f", &((txn+i*c)->m));
    fscanf(ftxn, "%f", &((txn+i*c)->a));
    fscanf(ftxn, "%f", &((txn+i*c)->b));

    i++;
    while (!feof(ftxn)&&i<atoi(argv[3]))
    {
      fscanf (ftxn, "%f", txn+i*4);//tmp value
      if(*(txn+i*c)==0){printf("Not enough transactions in file\n");exit(-1);}
      repA(j,0,3)fscanf (ftxn, "%f", txn+i*c+j);
      i++;
    }
    if(i<atoi(argv[3])){printf("Not enough transactions in file\n");exit(-1);}

    asize = lseek(facc, 0, SEEK_END);
    if(asize <= 0){perror("lseek");exit(-1);}

    if(lseek(facc, 0, SEEK_SET) != 0){perror("lseek");exit(-1);}

    buff = malloc(asize);
    if(!buff){perror("mem");exit(-1);}

    do{
         ul bytes;
         cbuff = buff + bytes_read;
         bytes = read(facc, cbuff, asize - bytes_read);
         if(bytes < 0){
             perror("read");
             exit(-1);
         }
        bytes_read += bytes;
     }while(asize != bytes_read);
    //
    //  hash_count = asize / BLOCK_SIZE;
    //  if(asize % BLOCK_SIZE)++hash_count;
    //
    //  hashes = malloc(sizeof(ul) * hash_count);
    //  if(!hashes){perror("mem");exit(-1);}
    //
    //  dataptr = buff;
    //  optr = hashes;
    //
    //  pthread_mutex_init(&lock, NULL);
    //
    //  cbuff = buff + asize;
    //
    //  if(THREADS>MAX_THREADS){printf("Use less than %d threads.\n",MAX_THREADS);exit(-1);}
    //
    //  rep(i,THREADS){if(pthread_create(&threads[i], NULL, hashit, cbuff) != 0){perror("pthread_create");exit(-1);}}
    //  rep(i,THREADS)pthread_join(threads[i], NULL);
    //  rep(i,hash_count)printf("block# %d hash %lx\n", i, hashes[i]);
    //
    //  free(hashes);
    //  free(buff);
     close(facc);
     close(ftxn);
}
