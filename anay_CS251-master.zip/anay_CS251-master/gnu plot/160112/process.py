import subprocess as sub
import numpy as np

log=open("output.log","r");
d_scat1=open("d_scat1.txt","w");
d_scat2=open("d_scat2.txt","w");
d_scat4=open("d_scat4.txt","w");
d_scat8=open("d_scat8.txt","w");
d_scat16=open("d_scat16.txt","w");
d_line=open("data_line.txt","w");

ite=100

j=0;mu=0.0;var=0.0;mu2=0.0;var2=0.0;

val=dict();
val2=dict();
par=dict();

for i in log:
    j+=1;
    if i[-1]=="\n":
        i=i[:-1];
    p,th,t=i.split(" ");
    par[p]=1;
    t=float(t);

    if th=='1':
        d_scat1.write("%s %s %s\n"% (p,th,t));
    elif th=='2':
        d_scat2.write("%s %s %s\n"% (p,th,t));
    elif th=='4':
        d_scat4.write("%s %s %s\n"% (p,th,t));
    elif th=='8':
        d_scat8.write("%s %s %s\n"% (p,th,t));
    elif th=='16':
        d_scat16.write("%s %s %s\n"% (p,th,t));

    mu+=t;var+=(t*t);
    mu2+=1.0/t;var2+=1.0/(t*t);

    if j==ite:
        j=0;
        mu/=ite*1.0;var/=ite*1.0;var-=mu*mu;
        mu2/=ite*1.0;var2/=ite*1.0;var2-=mu2*mu2;
        val[(p,th)]=[mu,var];
        val2[(p,th)]=[var2];
        mu=0;var=0;
        mu2=0;var2=0;

#non scatter
b=['1','2','4','8','16'];
for p in par:
    tmp=[];
    for th in b:
        tmp.append(val[(p,th)][0]);
        tmp.append(val[(p,th)][1]);
    for th in b:
        tmp.append(val2[(p,th)][0]);
    d_line.write("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n"% (p,tmp[0],tmp[1],tmp[2],tmp[3],tmp[4],tmp[5],tmp[6],tmp[7],tmp[8],tmp[9],tmp[10],tmp[11],tmp[12],tmp[13],tmp[14]));

log.close();
d_scat1.close();
d_scat2.close();
d_scat4.close();
d_scat8.close();
d_scat16.close();
d_line.close();
