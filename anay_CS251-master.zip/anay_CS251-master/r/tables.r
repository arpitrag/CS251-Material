student.data <-
    data.frame( student = 1:25,
               age = round(rnorm(25, mean = 18, sd = 3)),
               course = sample(paste("CS",320:325, sep="-"), 25, replace = TRUE))

student.data

table(student.data $ "course")
table(student.data $ "age")
table(student.data $ "age" < 18)

print(sample(1:6, size=10, prob=c(100,3,2,3,3,3), replace=TRUE))
