#include<stdio.h>
#include<stdlib.h>
#include<sys/time.h>
#include<fcntl.h>
#include <unistd.h>
#include<pthread.h>

#define rep(i,n) for(int i=0;i<(n);++i)
#define repA(i,a,n) for(int i=(a);i<=(n);++i)
#define repD(i,a,n) for(int i=(a);i>=(n);--i)

#define TDIFF(start, end) ((end.tv_sec - start.tv_sec) * 1000000UL + (end.tv_usec - start.tv_usec))

const int MAX_THREADS=64;
const int MAX=11009;
int nt=1,THREADS=1;

pthread_mutex_t lock;
int cur=0;

struct thread_param{
  pthread_t tid;
};
struct account {
  int id;
  double m;
  int use;
};
struct transaction {
  int ty;
  double m;
  int a,b;
};
struct transaction *txn;//variable

struct account acc[11009];

void calculate_and_execute(struct transaction *trans){//, struct account *a,struct account *b){
  int ia=trans->a,ib=trans->b;
  if(trans->ty==1)acc[ia].m+=trans->m*0.990;
  else if(trans->ty==2)acc[ia].m-=trans->m*1.010;
  else if(trans->ty==3)acc[ia].m*=1.071;
  else if(trans->ty==4){
    acc[ia].m-=trans->m*1.010;
    acc[ib].m+=trans->m*0.990;
  }
}

void* solve(void *t){
  struct transaction ctra;

  while(1){
    pthread_mutex_lock(&lock);
      if(cur>=nt){
        pthread_mutex_unlock(&lock);
        break;
      }
      ctra=txn[cur];

      if((ctra.a!=0&&acc[ctra.a].use==1)||(ctra.b!=0&&acc[ctra.b].use==1)){
        pthread_mutex_unlock(&lock);
        continue;
      }
      cur++;
      acc[ctra.a].use=1,acc[ctra.b].use=1;
    pthread_mutex_unlock(&lock);

    calculate_and_execute(&ctra);

    pthread_mutex_lock(&lock);
      acc[ctra.a].use=0;
      acc[ctra.b].use=0;
    pthread_mutex_unlock(&lock);
  }

  pthread_exit(NULL);
}

void readAcc(char* file,int num){
  FILE* facc;
  facc = fopen(file, "r");
  if(facc==NULL){printf("Can not open account file\n");exit(-1);}

  int i=0,tt=0,iid=0;
  fscanf(facc, "%d", &iid);acc[iid].id=iid;
  fscanf(facc, "%lf", &acc[iid].m);
  acc[iid].use=0;
  i++;
  while (!feof(facc)&&i<num)
  {
    fscanf(facc, "%d", &iid);acc[iid].id=iid;
    if(iid==0){printf("Not enough accounts in file\n");exit(-1);}
    fscanf(facc, "%lf", &acc[iid].m);
    acc[iid].use=0;
    i++;
  }
  if(i<num){printf("Not enough accounts in file\n");exit(-1);}

  fclose(facc);
}
void readTrans(char* file,int num){
  nt=num;
  FILE * ftxn;
  ftxn = fopen(file, "r");
  if(ftxn==NULL){printf("Can not open transaction file\n");exit(-1);}

  int i=0,tt=0;
  fscanf (ftxn, "%d", &tt);//tmp value
  fscanf(ftxn, "%d", &txn[i].ty);
  fscanf(ftxn, "%lf", &txn[i].m);
  fscanf(ftxn, "%d", &txn[i].a);
  fscanf(ftxn, "%d", &txn[i].b);
  i++;
  while (!feof(ftxn)&&i<num)
  {
    fscanf (ftxn, "%d", &tt);//tmp value
    if(tt==0){printf("Not enough transactions in file\n");exit(-1);}
    fscanf(ftxn, "%d", &txn[i].ty);
    fscanf(ftxn, "%lf", &txn[i].m);
    fscanf(ftxn, "%d", &txn[i].a);
    fscanf(ftxn, "%d", &txn[i].b);
    i++;
  }
  if(i<num){printf("Not enough transactions in file\n");exit(-1);}
  fclose(ftxn);
}

int main(int argc, char **argv)
{
  if(argc!=5){printf("Usage: %s <accounts> <transaction> #transaction #threads\n", argv[0]);exit(-1);}

  rep(i,MAX)acc[i].id=0;
  readAcc(argv[1],10000);

  txn=(struct transaction*)malloc((atoi(argv[3])+1)*sizeof(struct transaction));
  if(txn==NULL){perror("mem");exit(-1);}
  readTrans(argv[2],atoi(argv[3]));

  THREADS=atoi(argv[4]);
  if(THREADS>MAX_THREADS){printf("Use less than %d threads.\n",MAX_THREADS);exit(-1);}

  pthread_mutex_init(&lock, NULL);

  pthread_t threads[THREADS];
  struct thread_param th[MAX_THREADS];

  //preprocessing finishes
  rep(i,THREADS){if(pthread_create(&th[i].tid, NULL, solve, &th[i])!=0){perror("pthread_create");exit(-1);}}
  rep(i,THREADS)pthread_join(th[i].tid, NULL);

  //FILE* out=fopen("output.txt","w");
  rep(i,MAX)if(acc[i].id!=0)printf("%d %.2f\n",acc[i].id,acc[i].m);


  //fclose(out);
  free(txn);
  return 0;
}
