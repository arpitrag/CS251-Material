import numpy as np;
import matplotlib.pyplot as plt
from numpy import genfromtxt

data=genfromtxt('train.csv',delimiter=',');
data=data[~np.any(np.isnan(data), axis=1)];

x,y=np.split(data,2,1);
x=np.c_[np.ones(len(x)),x];

tmp = np.linalg.pinv(np.matmul(x.T,x));
wd=np.matmul(tmp,np.matmul(x.T,y));
print "w_direct is:",wd
plt.plot(x,y,color='red');
plt.plot(x,np.matmul(x,wd),color='blue');

#train
w=np.random.rand(2,1);
n=1;eta=1e-8;
for i in range(n):
	for j in range(len(x)):
		cx=x[j].T.reshape(2,1);
		w-=eta*(np.matmul(w.T,cx)-y[j])*cx;
		if j%1000==0:
			plt.plot(x,np.matmul(x,w),color='cyan');
			plt.pause(0.00001);
plt.show();
print "w_train is:",w
#test
test=genfromtxt('test.csv',delimiter=',');
test=test[~np.any(np.isnan(test), axis=1)];

xt,yt=np.split(test,2,1);
xt=np.c_[np.ones(len(xt)),xt];

cs1=np.sqrt(np.mean(np.square(np.matmul(xt,wd)-yt)));
cs2=np.sqrt(np.mean(np.square(np.matmul(xt,w)-yt)));
print "error: direct ",cs1,", iteration ",cs2;
